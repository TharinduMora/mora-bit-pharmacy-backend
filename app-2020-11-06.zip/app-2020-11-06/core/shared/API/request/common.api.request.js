ApiRequest = {
    STATUS_UPDATE_API: {
        BODY: {
            primaryId: 0,
            status: 0
        },
        MandatoryColumns: ["primaryId", "status"]
    },
};

module.exports = ApiRequest;
